import re
import matplotlib.pyplot as plt

with open("sequence.fasta") as f:
    lines = f.readlines()
dna_sequence = "".join(l.strip() for l in lines if not l.startswith(">")).upper()

enzymes = {
    'EcoRI':  {'site': 'GAATTC', 'cut': 1},
    'BamHI':  {'site': 'GGATCC', 'cut': 1},
    'HindIII':{'site': 'AAGCTT', 'cut': 1},
    'TaqI':   {'site': 'TCGA',   'cut': 1},
    'HaeIII': {'site': 'GGCC',   'cut': 2}
}

def digest_dna(sequence, enzyme_name, enzyme_info):
    site = enzyme_info['site']
    cut_offset = enzyme_info['cut']
    positions = [m.start() + cut_offset for m in re.finditer(site, sequence)]
    fragments = []
    prev = 0
    for pos in positions:
        fragments.append(pos - prev)
        prev = pos
    fragments.append(len(sequence) - prev)
    return positions, fragments

results = {}

for name, info in enzymes.items():
    positions, fragments = digest_dna(dna_sequence, name, info)
    results[name] = {
        'cleavages': len(positions),
        'positions': positions,
        'fragments': fragments
    }

for enzyme, data in results.items():
    pos_1based = [p + 1 for p in data['positions']]
    print(f"\n{enzyme}")
    print(f"Cleavage sites: {data['cleavages']}")
    print(f"Positions (1-based): {pos_1based}")
    print(f"Fragment sizes (bp): {data['fragments']}")

def simulate_gel(results):
    plt.figure(figsize=(8, 6))
    ax = plt.gca()
    ax.set_facecolor("black")

    all_frags = [f for data in results.values() for f in data['fragments']]
    if not all_frags:
        print("No bands to plot.")
        return

    lane_positions = range(len(results))
    lane_names = list(results.keys())
    lane_width = 1.0

    for i, (enzyme, data) in enumerate(results.items()):
        x_center = i * lane_width
        for frag in data['fragments']:
            migration = 1000.0 / frag
            x_left = x_center - 0.3
            x_right = x_center + 0.3
            plt.plot([x_left, x_right], [migration, migration], lw=6, color="white")

    ax.invert_yaxis()
    ax.set_xticks([i * lane_width for i in lane_positions])
    ax.set_xticklabels(lane_names, color="white")
    ax.tick_params(colors="white")
    for spine in ax.spines.values():
        spine.set_visible(False)

    ax.set_ylabel("Migration distance (1/fragment size)", color="white")
    ax.set_xlabel("Enzyme digest", color="white")
    ax.set_title("Simulated Electrophoresis Gel", color="white")
    plt.grid(False)
    plt.tight_layout()
    plt.show()

simulate_gel(results)
