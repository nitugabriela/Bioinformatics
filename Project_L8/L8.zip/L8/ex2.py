import re
import matplotlib.pyplot as plt

enzymes = {
    'EcoRI':  {'site': 'GAATTC', 'cut': 1},
    'BamHI':  {'site': 'GGATCC', 'cut': 1},
    'HindIII':{'site': 'AAGCTT', 'cut': 1},
    'TaqI':   {'site': 'TCGA',   'cut': 1},
    'HaeIII': {'site': 'GGCC',   'cut': 2}
}

genome_files = [
    "flu1.fna","flu2.fna","flu3.fna","flu4.fna","flu5.fna",
    "flu6.fna","flu7.fna","flu8.fna","flu9.fna","flu10.fna"
]

genome_names = [
    "Flu1","Flu2","Flu3","Flu4","Flu5",
    "Flu6","Flu7","Flu8","Flu9","Flu10"
]

def read_fasta(path):
    with open(path) as f:
        lines = f.readlines()
    seq = "".join(l.strip() for l in lines if not l.startswith(">")).upper()
    return seq

def digest_dna(sequence, enzyme_info):
    site = enzyme_info['site']
    cut_offset = enzyme_info['cut']
    positions = [m.start() + cut_offset for m in re.finditer(site, sequence)]
    fragments = []
    prev = 0
    for pos in positions:
        fragments.append(pos - prev)
        prev = pos
    fragments.append(len(sequence) - prev)
    return positions, fragments

def plot_gel(lanes_fragments, title, filename=None):
    plt.figure(figsize=(max(6, len(lanes_fragments)), 6))
    ax = plt.gca()
    ax.set_facecolor("black")

    lane_width = 1.0
    lane_names = list(lanes_fragments.keys())

    all_frags = [f for frags in lanes_fragments.values() for f in frags]
    if not all_frags:
        print("No bands to plot for", title)
        return

    for i, lane in enumerate(lane_names):
        x_center = i * lane_width
        for frag in lanes_fragments[lane]:
            migration = 1000.0 / frag
            x_left = x_center - 0.3
            x_right = x_center + 0.3
            ax.plot([x_left, x_right], [migration, migration], lw=6, color="white")

    ax.invert_yaxis()
    ax.set_xticks([i * lane_width for i in range(len(lane_names))])
    ax.set_xticklabels(lane_names, color="white", rotation=45, ha="right")
    ax.tick_params(colors="white")
    for spine in ax.spines.values():
        spine.set_visible(False)

    ax.set_ylabel("Migration distance (1/fragment size)", color="white")
    ax.set_xlabel("Lanes", color="white")
    ax.set_title(title, color="white")
    plt.grid(False)
    plt.tight_layout()
    if filename:
        plt.savefig(filename, dpi=300)
        print("Saved", filename)
    plt.show()

results = {}

for gfile, gname in zip(genome_files, genome_names):
    seq = read_fasta(gfile)
    print(f"Processing {gfile} ({gname}), length {len(seq)} bp")
    results[gname] = {}
    for ename, einfo in enzymes.items():
        positions, fragments = digest_dna(seq, einfo)
        results[gname][ename] = {
            "positions": positions,
            "fragments": fragments
        }

for gname in genome_names:
    print("Plotting full gel for", gname)
    lanes = {ename: results[gname][ename]["fragments"] for ename in enzymes.keys()}
    plot_gel(lanes, f"Gel – {gname}", f"gel_{gname}.png")

common_per_enzyme = {}
for ename in enzymes.keys():
    sets = [set(results[g][ename]["fragments"]) for g in genome_names]
    common = set.intersection(*sets)
    common_per_enzyme[ename] = common

diff_results = {}
for gname in genome_names:
    diff_results[gname] = {}
    for ename in enzymes.keys():
        original = results[gname][ename]["fragments"]
        common = common_per_enzyme[ename]
        diff = [f for f in original if f not in common]
        diff_results[gname][ename] = diff

for gname in genome_names:
    print("Plotting DIFF gel for", gname)
    lanes = {ename: diff_results[gname][ename] for ename in enzymes.keys()}
    plot_gel(lanes, f"Gel (differences only) – {gname}", f"gel_diff_{gname}.png")

merged_diff_lanes = {}
for gname in genome_names:
    s = set()
    for ename in enzymes.keys():
        s.update(diff_results[gname][ename])
    merged_diff_lanes[gname] = sorted(s)

print("Plotting merged DIFF gel")
plot_gel(merged_diff_lanes,
         "Merged electrophoresis gel – differences only",
         "gel_merged_differences.png")
